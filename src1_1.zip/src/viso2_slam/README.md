viso2_slam
==========
Original package - viso2: [github](https://github.com/srv/viso2), [Wiki](http://www.ros.org/wiki/viso2)

Kalman Filter implementation from [Hayk Martirosyan](https://github.com/hmartiro/kalman-cpp). KF is modified for pose usage.